package retake


import com.mongodb.MongoClientSettings
import com.mongodb.ServerAddress
import com.mongodb.client.MongoClients
import com.mongodb.client.MongoCollection
import org.bson.Document
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

class  ExerciseTwo {
	static void main(String[] args) {
		def jsonFilePath = 'src/main/resources/currency.json'
		
		// Read the JSON file using JsonSlurper
		def jsonSlurper = new JsonSlurper()
		def jsonData = jsonSlurper.parse(new File(jsonFilePath))
		
		def currencyData = jsonData as List
		
		
		println("All country currency in the world:")
		println(allCurrencyQuery(currencyData ) )
		println("\n")
		
		
		// 3. Data Filtering (Select * from ... where condition in SQL)
		println("Top performing currency (rate to dollar < 5.0):")
		println(filteredDocumentsQuery(currencyData ) )
		println("\n")
		
		
		println("Grouped Documents (Average Rate by First Letter of Currency Code):")
		println( topFiveCurrenciesPerContinent(currencyData))
		println("\n")

	
	}

	
	static String allCurrencyQuery(currencyCollection) {
		def formattedTable = new StringBuilder()
	
		// Append header row with column names
		formattedTable.append(String.format("| %-35s | %-10s | %-20s | %-20s |\n", "Country", "Code", "Continent", "Rate to USD"))
		formattedTable.append("|-------------------------------------|------------|--------------------|----------------------|\n")
	
		// Append data rows
		currencyCollection.each { entry ->
			def country = entry.containsKey("country") ? entry["country"].toString().padRight(35) : ""
			def code = entry.containsKey("code") ? entry["code"] : ""
			def continent = entry.containsKey("continent") ? entry["continent"].toString().padRight(20) : ""
			def rateToUSD = entry.containsKey("rate_to_usd") ? entry["rate_to_usd"] : ""
	
			formattedTable.append(String.format("| %-35s | %-10s | %-20s | %-20s |\n", country, code, continent, rateToUSD))
		}
	
		return formattedTable.toString()
	}
	
	

	static String filteredDocumentsQuery(List<Map<String, Object>> documents) {
		def formattedTable = new StringBuilder()
		formattedTable.append(String.format("| %-35s | %-20s |\n", "Country", "Rate to USD"))
		formattedTable.append("|-------------------------------------|----------------------|\n")
		
		// Filter documents where rate > 5
		def filteredDocuments = documents.findAll { doc ->
			doc.rate_to_usd < 5.0
		}
		
		// Iterate over filtered documents and format as table
		filteredDocuments.each { doc ->
			def country = doc.country.toString().padRight(35)
			def rateToUSD = doc.rate_to_usd
			formattedTable.append(String.format("| %-35s | %-20s |\n", country, rateToUSD))
		}
		
		return formattedTable.toString()
	}
	
	static String topFiveCurrenciesPerContinent(List<Map<String, Object>> currencies) {
		def formattedTable = new StringBuilder()
		formattedTable.append(String.format("| %-35s | %-20s | %-20s |\n", "Country", "Continent", "Rate to Dollar"))
		formattedTable.append("|-------------------------------------|----------------------|----------------------|\n")
	
		// Group currencies by continent
		def currenciesByContinent = currencies.groupBy { it.continent }
	
		// Iterate over each continent
		currenciesByContinent.each { continent, currencyList ->
			// Sort currency list by rate_to_usd in ascending order
			currencyList.sort { a, b -> a.rate_to_usd <=> b.rate_to_usd }
	
			// Take top five currencies
			def topFiveCurrencies = currencyList.take(5)
	
			// Append top five currencies to the table
			topFiveCurrencies.each { currency ->
				formattedTable.append(String.format("| %-35s | %-20s | %-20s |\n", currency.country, continent, currency.rate_to_usd))
			}
		}
	
		return formattedTable.toString()
	}
	

}