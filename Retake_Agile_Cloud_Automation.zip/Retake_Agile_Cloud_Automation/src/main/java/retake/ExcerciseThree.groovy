package retake


import com.mongodb.MongoClientSettings
import com.mongodb.ServerAddress
import com.mongodb.client.MongoClients
import com.mongodb.client.MongoCollection
import com.mongodb.client.model.Projections
import org.bson.Document
import org.bson.conversions.Bson
import groovy.json.JsonOutput

class ExerciseThree {
	static void main(String[] args) {
 def connectionString = "mongodb+srv://anigbojohnsona:Sonship123@cluster0.kybkuyh.mongodb.net/ReatakeAgileCloudAuthomation?retryWrites=true&w=majority" 

        // Connect to the MongoDB server using the connection string
        def mongoClient = MongoClients.create(connectionString)

        // Access a specific database
        def database = mongoClient.getDatabase("ReatakeAgileCloudAuthomation")

        // Access a specific collection in the database
        def collection = database.getCollection("currency")		
			
		println("Filtered countries whose (rate > 1000.0):")
        println(filterHighRateCountries(collection))
		println("\n")
		
		println("Give average rate of each conitinent rate to the dollar:")
		println(groupAvgRatePerContinent(collection))
		println("\n")
		
		
		println("Projection of all the country and its rates to the dollar:")
		println(projectCountryAndRates(collection))
		println("\n")
		
		println("Filtered and Aggregate Worst Ten performing currency to the dollar:")
		println(filterAggregateWorstPerformingCurrency(collection))
        
		mongoClient.close()
	}
	
		
	static String allDocumentsQuery(MongoCollection<Document> collection) {
		def formattedTable = new StringBuilder()
			formattedTable.append(String.format("| %-20s | %-20s |\n", "Code", "Rate"))
			formattedTable.append("|----------------------|----------------------|\n")
		
			def allDocuments = collection.find()
			allDocuments.each { doc ->
				   def code = doc.get("code")
				   def rate = doc.get("rate")
				   formattedTable.append(String.format("| %-20s | %-20s |\n", code, rate))
			
			}
		return formattedTable.toString()
		
		}
	

	static String filterHighRateCountries(MongoCollection<Document> collection) {
		def formattedTable = new StringBuilder()
		formattedTable.append(String.format("| %-20s | %-20s |\n", "Country", "Rate"))
		formattedTable.append("|----------------------|----------------------|\n")

		collection.find(new Document("rate_to_usd", new Document("\$gt", 1000))).forEach { doc ->
			def country = doc.getString("country")
			def rateToUSD = doc.getDouble("rate_to_usd")
			formattedTable.append(String.format("| %-20s | %-20s |\n", country, rateToUSD))
			
		}
		return formattedTable.toString()
	}
	
	static String groupAvgRatePerContinent(MongoCollection<Document> collection) {
		def formattedTable = new StringBuilder()
		formattedTable.append("| %-20s | %-20s |\n".format("Continent", "Average Rate to USD"))
		formattedTable.append("|----------------------|----------------------|\n")

		collection.aggregate([
			new Document("\$group", new Document("_id", "\$continent").append("avgRate", new Document("\$avg", "\$rate_to_usd")))
		]).forEach { doc ->
			def continent = doc.getString("_id")
			def avgRate = doc.getDouble("avgRate")
			formattedTable.append(String.format("| %-20s | %-20s |\n", continent, avgRate))
			
		}
		return formattedTable.toString()
	}

		
	static String filterAggregateWorstPerformingCurrency(MongoCollection<Document> collection) {
			def formattedTable = new StringBuilder()
			formattedTable.append(String.format("| %-35s | %-20s |\n", "Country", "Rate"))
			formattedTable.append("|-------------------------------------|----------------------|\n")
	
			// Aggregate pipeline to sort documents based on rate_to_usd and limit to top 10
			def pipeline = [
				new Document('$sort', new Document('rate_to_usd', -1)), // Sort by rate_to_usd in descending order
				new Document('$limit', 10), // Limit to top 10 documents
				new Document('$project', new Document('country', 1).append('rate_to_usd', 1)) // Project only country and rate_to_usd fields
			]
	
			// Perform aggregation
			collection.aggregate(pipeline).forEach { doc ->
				def country = doc.getString("country")
				def rateToUSD = doc.get("rate_to_usd") instanceof Integer ? doc.getInteger("rate_to_usd").doubleValue() : doc.getDouble("rate_to_usd")
				formattedTable.append(String.format("| %-35s | %-20s |\n", country, rateToUSD))
			}
			return formattedTable.toString()
		}
	
	
	static String projectCountryAndRates(MongoCollection<Document> collection) {
		def formattedTable = new StringBuilder()
		formattedTable.append(String.format("| %-35s | %-20s |\n", "Country", "Rate"))
		
		formattedTable.append("|-------------------------------------|----------------------|\n")
		
		def projection = new Document("country", 1).append("rate_to_usd", 1)
		
		collection.find().projection(projection).forEach { doc ->
			def country = doc.getString("country")
			def rateToUSD = doc.get("rate_to_usd") instanceof Integer ? doc.getInteger("rate_to_usd").doubleValue() : doc.getDouble("rate_to_usd")
			formattedTable.append(String.format("| %-35s | %-20s |\n", country, rateToUSD))
			
					}
		return formattedTable.toString()
	}

}