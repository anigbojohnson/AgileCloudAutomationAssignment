Retake Project Instructions


Run Your Queries

1. Locate "ExcerciseOne.groovy" at "/Retake_Agile_Cloud_Automation/src/main/java/retake/ExcerciseOne.groovy"
Right-click on the file, choose "Run As," and select "Java Application"

2. View your console for result of your queries

How To Run Test

1. Locate "ExerciseOneTest.groovy" at "/Retake_Agile_Cloud_Automation/src/test/java/exerciseOneTest/ExerciseOneTest.groovy"
Right-click on the file, choose "Run As," and select "JUnit Test"
